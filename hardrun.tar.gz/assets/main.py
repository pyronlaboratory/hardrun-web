import asyncio
import pygame  # noqa: F401

from source.game import Game


async def main():
    game = Game()

    while True:
        game.update_frame()
        await asyncio.sleep(0)


if __name__ == "__main__":
    asyncio.run(main())

# Profiling --
# import asyncio
# import pygame  # noqa: F401
# import time
# from source.game import Game


# async def main():
#     await asyncio.sleep(0)
#     game = Game()

#     frame_count = 0
#     timings = {}

#     while True:
#         frame_count += 1
#         frame_start = time.time()  # noqa: F841

#         # --- Profile each section individually ---
#         t = time.time()
#         game.clouds.update()
#         game.clouds.render(game.display, offset=(0, 0))
#         timings["clouds"] = timings.get("clouds", 0) + (time.time() - t)

#         t = time.time()
#         game.tilemap.render(game.display, offset=(0, 0))
#         timings["tilemap"] = timings.get("tilemap", 0) + (time.time() - t)

#         t = time.time()
#         for enemy in game.enemies:
#             enemy.update(game.tilemap, (0, 0))
#             enemy.render(game.display, offset=(0, 0))
#         timings["enemies"] = timings.get("enemies", 0) + (time.time() - t)

#         t = time.time()
#         for particle in game.particles:
#             particle.update()
#             particle.render(game.display, offset=(0, 0))
#         timings["particles"] = timings.get("particles", 0) + (time.time() - t)

#         t = time.time()
#         game.update_frame()
#         timings["full_frame"] = timings.get("full_frame", 0) + (time.time() - t)

#         # Print every 60 frames
#         if frame_count % 60 == 0:
#             print(f"\n--- Frame {frame_count} timings (avg over 60 frames) ---")
#             for key, total in timings.items():
#                 print(f"  {key}: {(total / 60) * 1000:.2f}ms")
#             timings = {}

#         await asyncio.sleep(0)


# if __name__ == "__main__":
#     asyncio.run(main())
