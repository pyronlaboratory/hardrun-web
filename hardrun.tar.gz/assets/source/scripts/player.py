import math
import random

from source.scripts.entities import PhysicsEntity
from source.scripts.particles import Particles


class Player(PhysicsEntity):
    def __init__(self, game, position, size):
        super().__init__(game, "player", position, size)
        self.air_time = 0
        self.jumps = 2
        self.wall_slide = False
        self.dashing = 0

    def render(self, surf, offset=(0, 0)):
        if abs(self.dashing) <= 50:
            super().render(surf, offset=offset)

    def update(self, tilemap, movement=(0, 0)):
        super().update(tilemap, movement=movement)
        self.air_time += 1

        if self.air_time > 200:
            if not self.game.dead:
                self.game.screenshake = max(16, self.game.screenshake)
            self.game.dead += 1

        if self.collisions["down"]:
            self.air_time = 0
            self.jumps = 2

        self.wall_slide = False
        if (self.collisions["right"] or self.collisions["left"]) and self.air_time > 4:
            self.wall_slide = True
            self.velocity[1] = min(self.velocity[1], 0.5)  # type: ignore
            if self.collisions["right"]:
                self.flip = False
            else:
                self.flip = True
            self.set_action("fall")

        if not self.wall_slide:
            if self.air_time > 4:
                if self.velocity[1] < 0:
                    self.set_action("jump")
                elif self.velocity[1] > 0:
                    self.set_action("fall")
            elif movement[0] != 0:
                self.set_action("run")
            else:
                self.set_action("idle")

        if self.dashing > 0:
            self.dashing = max(0, self.dashing - 1)
        if self.dashing < 0:
            self.dashing = min(0, self.dashing + 1)
        if abs(self.dashing) > 50:
            self.velocity[0] = abs(self.dashing) / self.dashing * 8  # type: ignore
            if abs(self.dashing) == 51:
                self.velocity[0] *= 0.1  # type: ignore
            particle_velocity = [
                abs(self.dashing) / self.dashing * random.random() * 3,
                0,
            ]
            self.game.particles.append(
                Particles(
                    self.game,
                    "strike",
                    self.rect().center,
                    velocity=particle_velocity,
                    frame=random.randint(0, 7),
                )
            )
        if abs(self.dashing) in {60, 50}:
            for i in range(20):
                angle = random.random() * math.pi * 2
                speed = random.random() * 0.5 + 0.5
                particle_velocity = [math.cos(angle) * speed, math.sin(angle) * speed]
                self.game.particles.append(
                    Particles(
                        self.game,
                        "strike",
                        self.rect().center,
                        velocity=particle_velocity,
                        frame=random.randint(0, 7),
                    )
                )

        if self.velocity[0] > 0:
            self.velocity[0] = max(self.velocity[0] - 0.1, 0)  # type: ignore
        else:
            self.velocity[0] = min(self.velocity[0] + 0.1, 0)  # type: ignore

    def jump(self):
        if self.wall_slide:
            if self.flip and self.last_movement[0] < 0:
                self.velocity[0] = 3.5  # type: ignore
                self.velocity[1] = -2.5  # type: ignore
                self.air_time = 5
                self.jumps = max(0, self.jumps - 1)
                return True

            elif not self.flip and self.last_movement[0] > 0:
                self.velocity[0] = -3.5  # type: ignore
                self.velocity[1] = -2.5  # type: ignore
                self.air_time = 5
                self.jumps = max(0, self.jumps - 1)
                return True

        elif self.jumps:
            self.velocity[1] = -3
            self.jumps -= 1
            self.air_time = 5
            return True

    def dash(self):
        if not self.dashing:
            self.game.sfx["dash"].play()
            if self.flip:
                self.dashing = -60
            else:
                self.dashing = 60
