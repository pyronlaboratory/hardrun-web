import math
import random

from source.scripts.entities import PhysicsEntity
from source.scripts.particles import Particles
from source.scripts.sparks import Sparks


class Enemy(PhysicsEntity):
    def __init__(self, game, position, size):
        super().__init__(game, "enemy", position, size)
        self.walking = 0

    def render(self, surf, offset=(0, 0)):
        super().render(surf, offset=offset)

    def update(self, tilemap, movement=(0, 0)):  # type: ignore
        if self.walking:
            if tilemap.solid_check(
                (self.rect().centerx + (-7 if self.flip else 7), self.position[1] + 23)
            ):
                if self.collisions["right"] or self.collisions["left"]:
                    self.flip = not self.flip
                else:
                    movement = (movement[0] - 0.5 if self.flip else 0.5, movement[1])
            else:
                self.flip = not self.flip
            self.walking = max(0, self.walking - 1)

            if not self.walking:
                distance = (
                    self.game.player.position[0] - self.position[0],
                    self.game.player.position[1] - self.position[1],
                )
                if abs(distance[1]) < 16:
                    if self.flip and distance[0] < 0:
                        self.game.sfx["shoot"].play()
                        self.game.projectiles.append(
                            [[self.rect().centerx - 7, self.rect().centery], -1.5, 0]
                        )
                        for i in range(4):
                            self.game.sparks.append(
                                Sparks(
                                    self.game.projectiles[-1][0],
                                    random.random() - 0.5 + math.pi,
                                    2 + random.random(),
                                )
                            )
                    if not self.flip and distance[0] > 0:
                        self.game.sfx["shoot"].play()
                        self.game.projectiles.append(
                            [[self.rect().centerx + 7, self.rect().centery], 1.5, 0]
                        )
                        for i in range(4):
                            self.game.sparks.append(
                                Sparks(
                                    self.game.projectiles[-1][0],
                                    random.random() - 0.5,
                                    2 + random.random(),
                                )
                            )

        elif random.random() < 0.01:
            self.walking = random.randint(30, 120)

        super().update(tilemap, movement=movement)

        if movement[0] != 0:
            self.set_action("run")
        else:
            self.set_action("idle")

        if abs(self.game.player.dashing) >= 50:
            if self.rect().colliderect(self.game.player.rect()):
                self.game.screenshake = max(16, self.game.screenshake)
                self.game.sfx["hit"].play()
                for i in range(30):
                    angle = random.random() * math.pi * 2
                    speed = random.random() * 5
                    self.game.sparks.append(
                        Sparks(self.rect().center, angle, 2 + random.random())
                    )
                    self.game.particles.append(
                        Particles(
                            self.game,
                            "strike",
                            self.rect().center,
                            velocity=[
                                math.cos(angle + math.pi) * speed * 0.5,
                                math.sin(angle + math.pi) * speed * 0.5,
                            ],
                            frame=random.randint(0, 7),
                        )
                    )
                self.game.sparks.append(
                    Sparks(self.rect().center, 0, 5 + random.random())
                )
                self.game.sparks.append(
                    Sparks(self.rect().center, math.pi, 5 + random.random())
                )
                return True
