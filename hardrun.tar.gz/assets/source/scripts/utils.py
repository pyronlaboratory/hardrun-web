import os
import sys
import shutil
import pygame

# Detect if we are running a PyInstaller bundle
if hasattr(sys, "_MEIPASS"):
    BASE_DIR = sys._MEIPASS  # type: ignore
else:
    BASE_DIR = os.path.abspath(".")

BASE_IMAGE_PATH = os.path.join(BASE_DIR, "source", "assets")


def load_image(path):  # type: ignore
    full_path = os.path.join(BASE_IMAGE_PATH, path)
    image = pygame.image.load(full_path).convert()
    image.set_colorkey((0, 0, 0))
    return image


def load_image(path, scale=None, crop=True):  # noqa: F811
    full_path = os.path.join(BASE_IMAGE_PATH, path)
    img = pygame.image.load(full_path).convert()
    img.set_colorkey((0, 0, 0))
    img = auto_crop(img) if crop is True else img
    return pygame.transform.scale(img, scale) if scale is not None else img


def load_assets(path, crop=True):
    images = []
    dir_path = os.path.join(BASE_IMAGE_PATH, path)
    for img_name in sorted(os.listdir(dir_path)):
        image = load_image(path + "/" + img_name, crop=crop)
        images.append(image)
    return images


def auto_crop(image: pygame.Surface) -> pygame.Surface:
    rect = image.get_bounding_rect()
    return image.subsurface(rect).copy()


def rename_and_reorder_images(folder_path):
    files = [f for f in os.listdir(folder_path) if f.endswith(".png")]
    files.sort(key=lambda x: int(os.path.splitext(x)[0]))

    for new_index, filename in enumerate(files):
        old_path = os.path.join(folder_path, filename)
        new_filename = f"{new_index}.png"
        new_path = os.path.join(folder_path, new_filename)

        if old_path != new_path:
            temp_path = os.path.join(folder_path, f"temp_{new_index}.png")
            shutil.move(old_path, temp_path)

    for f in os.listdir(folder_path):
        if f.startswith("temp_") and f.endswith(".png"):
            new_index = f.split("_")[1]
            shutil.move(
                os.path.join(folder_path, f), os.path.join(folder_path, f"{new_index}")
            )
