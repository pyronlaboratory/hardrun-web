import os
import pygame

DEBUG = os.getenv("DEBUG", "0") == "1"


class PhysicsEntity:
    def __init__(self, game, entity, position, size):
        self.game = game
        self.entity = entity
        self.position = list(position)
        self.size = size
        self.velocity = [0, 0]
        self.last_movement = [0, 0]
        self.collisions = {"up": False, "down": False, "right": False, "left": False}
        self.action = ""
        self.anim_offset = (0, 0)
        self.flip = False
        self.set_action("idle")

    def render(self, surf, offset=(0, 0)):
        surf.blit(
            pygame.transform.flip(self.animation.img(), self.flip, False),
            (
                self.position[0] - offset[0] + self.anim_offset[0],
                self.position[1] - offset[1] + self.anim_offset[1],
            ),
        )

        if DEBUG:
            debug_rect = self.rect().copy()
            debug_rect.topleft = (debug_rect.x - offset[0], debug_rect.y - offset[1])
            pygame.draw.rect(surf, (255, 0, 0), debug_rect, 1)

    def update(self, tilemap, movement=(0, 0)):
        frame_movement = (
            movement[0] + self.velocity[0],
            movement[1] + self.velocity[1],
        )
        self.position[0] += frame_movement[0]
        self.collisions = {"up": False, "down": False, "right": False, "left": False}
        entity_rect = self.rect()

        for rect in tilemap.physics_rects_around(self.position, self.size):
            if entity_rect.colliderect(rect):
                if frame_movement[0] > 0:
                    entity_rect.right = rect.left
                    self.collisions["right"] = True
                if frame_movement[0] < 0:
                    entity_rect.left = rect.right
                    self.collisions["left"] = True
                self.position[0] = entity_rect.x

        self.position[1] += frame_movement[1]
        entity_rect = self.rect()

        for rect in tilemap.physics_rects_around(self.position, self.size):
            if entity_rect.colliderect(rect):
                if frame_movement[1] > 0:
                    entity_rect.bottom = rect.top
                    self.collisions["down"] = True
                if frame_movement[1] < 0:
                    entity_rect.top = rect.bottom
                    self.collisions["up"] = True
                self.position[1] = entity_rect.y

        if movement[0] > 0:
            self.flip = False
        if movement[0] < 0:
            self.flip = True
        self.last_movement = movement

        self.velocity[1] = min(5, self.velocity[1] + 0.1)  # type: ignore

        if self.collisions["down"] or self.collisions["up"]:
            self.velocity[1] = 0

        self.animation.update()

    def rect(self):
        return pygame.Rect(
            self.position[0], self.position[1], self.size[0], self.size[1]
        )

    def set_action(self, action):
        if action != self.action:
            self.action = action
            self.animation = self.game.assets[self.entity + "/" + self.action].copy()
