import os
import sys
import pygame
import json

# Detect if we are running a PyInstaller bundle
if hasattr(sys, "_MEIPASS"):
    BASE_DIR = sys._MEIPASS  # type: ignore
else:
    BASE_DIR = os.path.abspath(".")

BASE_IMAGE_PATH = os.path.join(BASE_DIR)

DEBUG = os.getenv("DEBUG", "0") == "1"
NEIGHBOURS = [
    (-1, 0),
    (-1, -1),
    (0, -1),
    (1, -1),
    (1, 0),
    (0, 0),
    (-1, 1),
    (0, 1),
    (1, 1),
]
PHYSICS_ENABLED = {"grass", "land", "brick"}
AUTOTILE_ENABLED = {"grass", "land"}
AUTOTILE_MAP = {
    tuple(sorted([(1, 0), (0, 1)])): 0,
    tuple(sorted([(1, 0), (0, 1), (-1, 0)])): 1,
    tuple(sorted([(-1, 0), (0, 1)])): 2,
    tuple(sorted([(-1, 0), (0, -1), (0, 1)])): 3,
    tuple(sorted([(-1, 0), (0, -1)])): 4,
    tuple(sorted([(-1, 0), (0, -1), (1, 0)])): 5,
    tuple(sorted([(1, 0), (0, -1)])): 6,
    tuple(sorted([(1, 0), (0, -1), (0, 1)])): 7,
    tuple(sorted([(1, 0), (-1, 0), (0, 1), (0, -1)])): 8,
}


class Tilemap:
    def __init__(self, game, tile_size=32):
        self.game = game
        self.tile_size = tile_size
        self.tilemap = {}
        self.offgrid_tiles = []

    def autotile(self):
        for loc in self.tilemap:
            tile = self.tilemap[loc]
            neighbours = set()

            for shift in [(1, 0), (-1, 0), (0, -1), (0, 1)]:
                check_loc = (
                    str(tile["pos"][0] + shift[0])
                    + ";"
                    + str(tile["pos"][1] + shift[1])
                )
                if check_loc in self.tilemap:
                    if self.tilemap[check_loc]["type"] == tile["type"]:
                        neighbours.add(shift)

            neighbours = tuple(sorted(neighbours))
            if (tile["type"] in AUTOTILE_ENABLED) and (neighbours in AUTOTILE_MAP):
                tile["variant"] = AUTOTILE_MAP[neighbours]

    def tiles_around(self, pos):
        tiles = []
        tile_loc = (int(pos[0] // self.tile_size), int(pos[1] // self.tile_size))

        for offset in NEIGHBOURS:
            check_loc = (
                str(tile_loc[0] + offset[0]) + ";" + str(tile_loc[1] + offset[1])
            )

            if check_loc in self.tilemap:
                tiles.append(self.tilemap[check_loc])

        return tiles

    def solid_check(self, pos):
        tile_loc = (
            str(int(pos[0] // self.tile_size))
            + ";"
            + str(int(pos[1] // self.tile_size))
        )

        if (
            tile_loc in self.tilemap
            and self.tilemap[tile_loc]["type"] in PHYSICS_ENABLED
        ):
            return self.tilemap[tile_loc]

    def physics_rects_around(self, pos):  # type: ignore
        rects = []
        for tile in self.tiles_around(pos):
            if tile["type"] in PHYSICS_ENABLED:
                rects.append(
                    pygame.Rect(
                        tile["pos"][0] * self.tile_size,
                        tile["pos"][1] * self.tile_size,
                        self.tile_size,
                        self.tile_size,
                    )
                )
        return rects

    def physics_rects_around(self, pos, size):  # noqa: F811
        rects = []
        x_start = int(pos[0] // self.tile_size) - 1
        x_end = int((pos[0] + size[0]) // self.tile_size) + 1
        y_start = int(pos[1] // self.tile_size) - 1
        y_end = int((pos[1] + size[1]) // self.tile_size) + 1

        for x in range(x_start, x_end + 1):
            for y in range(y_start, y_end + 1):
                key = f"{x};{y}"
                if key in self.tilemap and self.tilemap[key]["type"] in PHYSICS_ENABLED:
                    rects.append(
                        pygame.Rect(
                            x * self.tile_size,
                            y * self.tile_size,
                            self.tile_size,
                            self.tile_size,
                        )
                    )

        return rects

    def render(self, surf, offset=(0, 0)):
        for tile in self.offgrid_tiles:
            tile_type = tile["type"]
            variant = tile["variant"]

            if tile_type in self.game.assets and variant < len(
                self.game.assets[tile_type]
            ):
                surf.blit(
                    self.game.assets[tile_type][variant],
                    (tile["pos"][0] - offset[0], tile["pos"][1] - offset[1]),
                )
            else:
                print(
                    f"[WARNING] Missing asset for type '{tile_type}', variant {variant} (offgrid)"
                )

        for x in range(
            offset[0] // self.tile_size,
            (offset[0] + surf.get_width()) // self.tile_size + 1,
        ):
            for y in range(
                offset[1] // self.tile_size,
                (offset[1] + surf.get_height()) // self.tile_size + 1,
            ):
                loc = str(x) + ";" + str(y)
                if loc in self.tilemap:
                    tile = self.tilemap[loc]
                    tile_type = tile["type"]
                    variant = tile["variant"]
                    pos = (
                        tile["pos"][0] * self.tile_size - offset[0],
                        tile["pos"][1] * self.tile_size - offset[1],
                    )

                    if tile_type in self.game.assets and variant < len(
                        self.game.assets[tile_type]
                    ):
                        surf.blit(self.game.assets[tile_type][variant], pos)
                    else:
                        print(
                            f"[WARNING] Missing asset for type '{tile_type}', variant {variant} at tile {loc}"
                        )

                    if DEBUG and tile_type in PHYSICS_ENABLED:
                        pygame.draw.rect(
                            surf,
                            (0, 255, 0),
                            pygame.Rect(pos, (self.tile_size, self.tile_size)),
                            1,
                        )

    def save(self, path):
        f = open(path, "w")
        json.dump(
            {
                "tilemap": self.tilemap,
                "tile_size": self.tile_size,
                "offgrid": self.offgrid_tiles,
            },
            f,
        )
        f.close()

    def load(self, path):
        full_path = os.path.join(BASE_IMAGE_PATH, path)
        f = open(full_path, "r")
        map_data = json.load(f)
        f.close()

        self.tilemap = map_data["tilemap"]
        self.tile_size = map_data["tile_size"]
        self.offgrid_tiles = map_data["offgrid"]

    def extract(self, id_pairs, keep=False):
        matches = []
        for tile in self.offgrid_tiles.copy():
            if (tile["type"], tile["variant"]) in id_pairs:
                matches.append(tile.copy())
                if not keep:
                    self.offgrid_tiles.remove(tile)

        for loc in list(self.tilemap):
            tile = self.tilemap[loc]
            if (tile["type"], tile["variant"]) in id_pairs:
                matches.append(tile.copy())
                matches[-1]["pos"] = matches[-1]["pos"].copy()
                matches[-1]["pos"][0] *= self.tile_size
                matches[-1]["pos"][1] *= self.tile_size
                if not keep:
                    del self.tilemap[loc]

        return matches
