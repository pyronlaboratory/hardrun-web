import os
import sys
import math
import pygame
import random

from source.scripts.player import Player
from source.scripts.enemy import Enemy
from source.scripts.clouds import Clouds
from source.scripts.tilemap import Tilemap
from source.scripts.sparks import Sparks
from source.scripts.particles import Particles
from source.scripts.animations import Animation
from source.scripts.utils import load_image, load_assets

# TODO
# Bug fix: Death condition
# Sliding particles effects while and possibly different animation than "fall"
# Make sliding jumpback more smooth
# Add Additional Element: Enemy type/Boss, Water, Spikes
# Animate: Flag, Trees
# Lock from scrolling left and bottom
# Better transition effects, UI and HUD
# Add more interactive and diff backgrounds
# Add game icon for start script
# Code refactoring.. and improved performance, and optimised bundle size

# Detect if we are running a PyInstaller bundle
if hasattr(sys, "_MEIPASS"):
    BASE_DIR = sys._MEIPASS  # type: ignore
else:
    BASE_DIR = os.path.abspath(".")

BASE_RESOURCE_PATH = os.path.join(BASE_DIR, "source")
OFFSET = (300, 300)
TILE_SIZE = 32


class Game:
    def __init__(self):
        pygame.init()
        pygame.display.set_caption("Hardrun v1.0.1")

        # self.screen_width, self.screen_height = 1280, 720
        # self.screen = pygame.display.set_mode((self.screen_width, self.screen_height))
        # self.display = pygame.Surface(
        #     (self.screen_width / 2, self.screen_height / 2), pygame.SRCALPHA
        # )
        # self.display_2 = pygame.Surface((self.screen_width / 2, self.screen_height / 2))

        self.screen_width, self.screen_height = 640, 360
        self.screen = pygame.display.set_mode((640, 360))
        self.display = pygame.Surface((640, 360))  # no SRCALPHA, no scaling needed
        self.display_2 = pygame.Surface((640, 360))

        self.clock = pygame.time.Clock()

        self.assets = {
            "player": load_image("player.png"),
            "clouds": load_assets("clouds"),
            "land": load_assets("tiles/land"),
            "brick": load_assets("tiles/brick"),
            "grass": load_assets("tiles/grass"),
            "decor": load_assets("tiles/decor"),
            "trees": load_assets("tiles/trees"),
            "projectile": load_image("projectile.png"),
            "enemy/idle": Animation(
                [
                    pygame.transform.flip(img, True, False)
                    for img in load_assets("enemy/idle")
                ],
                img_dur=9,
            ),
            "enemy/run": Animation(
                [
                    pygame.transform.flip(img, True, False)
                    for img in load_assets("enemy/run")
                ],
                img_dur=7,
            ),
            "player/idle": Animation(load_assets("player/idle"), img_dur=6),
            "player/run": Animation(load_assets("player/run"), img_dur=6),
            "player/jump": Animation(load_assets("player/jump"), img_dur=6),
            "player/fall": Animation(load_assets("player/fall"), img_dur=1),
            "particle/leaf": Animation(
                load_assets("particle/leaf"), img_dur=20, loop=False
            ),
            "particle/strike": Animation(
                load_assets("particle/strike"), img_dur=6, loop=False
            ),
        }
        self.sfx = {
            # TODO: Refactor base sfx path
            "jump": pygame.mixer.Sound("./source/assets/sfx/jump.ogg"),
            "dash": pygame.mixer.Sound("./source/assets/sfx/dash.ogg"),
            "hit": pygame.mixer.Sound("./source/assets/sfx/hit.ogg"),
            "shoot": pygame.mixer.Sound("./source/assets/sfx/shoot.ogg"),
            "dead": pygame.mixer.Sound("./source/assets/sfx/dead.ogg"),
            "win": pygame.mixer.Sound("./source/assets/sfx/win.ogg"),
            "ambience": pygame.mixer.Sound("./source/assets/sfx/ambience.ogg"),
        }
        self.sfx["ambience"].set_volume(0.2)
        self.sfx["shoot"].set_volume(0.6)
        self.sfx["hit"].set_volume(0.6)
        self.sfx["dash"].set_volume(0.2)
        self.sfx["jump"].set_volume(0.7)
        self.sfx["dead"].set_volume(0.2)
        self.sfx["win"].set_volume(0.01)

        self.player = Player(self, (0, 0), (24, 28))
        self.movement = [False, False]
        self.clouds = Clouds(self.assets["clouds"], count=10)
        self.tilemap = Tilemap(self, tile_size=TILE_SIZE)
        self.screenshake = 0
        self.win_timer = 0
        self.win_triggered = False
        self.dead_timer = 0
        self.dead_triggered = False
        self.level = 0
        self.load_level(self.level)
        self.load_and_scale_background("./source/assets/water.png")

        pygame.mixer.music.load("./source/assets/background.ogg")
        pygame.mixer.music.set_volume(0.02)
        pygame.mixer.music.play(-1)

        self.sfx["ambience"].play(-1)

    # def load_and_scale_background(self, path):
    #     img = pygame.image.load(path)
    #     img_rect = img.get_rect()

    #     # Calculate the scaling factor to maintain aspect ratio
    #     scale_w = self.screen_width / img_rect.width
    #     scale_h = self.screen_height / img_rect.height
    #     scale = min(scale_w, scale_h)

    #     new_width = int(img_rect.width * scale)
    #     new_height = int(img_rect.height * scale)

    #     self.bg_image = pygame.transform.smoothscale(img, (new_width, new_height))
    #     self.bg_pos = (
    #         (self.screen_width - new_width) // 2 - OFFSET[0],
    #         (self.screen_height - new_height) // 2 - OFFSET[1],
    #     )

    def load_and_scale_background(self, path):
        img = pygame.image.load(path).convert()
        img_rect = img.get_rect()

        scale_w = self.screen_width / img_rect.width
        scale_h = self.screen_height / img_rect.height
        scale = max(scale_w, scale_h)  # use max to fill, not min to fit

        new_width = int(img_rect.width * scale)
        new_height = int(img_rect.height * scale)

        self.bg_image = pygame.transform.smoothscale(img, (new_width, new_height))
        self.bg_pos = (
            (self.screen_width - new_width) // 2,  # no OFFSET
            (self.screen_height - new_height) // 2,
        )

    def load_level(self, map_id):
        self.tilemap.load("./source/scenes/" + str(map_id) + ".json")

        self.leaf_spawners = []
        for tree in self.tilemap.extract([("trees", 2)], keep=True):
            self.leaf_spawners.append(
                pygame.Rect(4 + tree["pos"][0], 4 + tree["pos"][1], 23, 13)
            )

        self.enemies = []
        for spawner in self.tilemap.extract([("spawners", 0), ("spawners", 1)]):
            if spawner["variant"] == 0:
                self.player.position = spawner["pos"]
                self.player.air_time = 0
            else:
                self.enemies.append(Enemy(self, spawner["pos"], (22, 22)))

        self.projectiles = []
        self.sparks = []
        self.particles = []
        self.scroll = [0, 0]
        self.dead = 0
        self.transition = -30

    def update_frame(self):
        fps = self.clock.get_fps()
        pygame.display.set_caption(f"Hardrun - {fps:.0f} FPS")

        # Reset frame
        self.display.fill((0, 0, 0, 0))
        self.display.blit(self.bg_image, self.bg_pos)
        self.screenshake = max(0, self.screenshake - 1)

        if not len(self.enemies):
            if not self.win_triggered:
                self.win_triggered = True
                self.win_timer = pygame.time.get_ticks()

            # Delay transition for 2 seconds
            if pygame.time.get_ticks() - self.win_timer > 2000:
                self.sfx["win"].play()
                self.transition = -30
                self.level = min(
                    self.level + 1,
                    len(os.listdir(BASE_RESOURCE_PATH + "/scenes")) - 1,
                )
                self.load_level(self.level)
                self.win_triggered = False  # Reset flag

        if self.transition < 0:
            self.transition += 1

        if self.dead:
            if not self.dead_triggered:
                self.sfx["dead"].play()
                self.dead_triggered = True
                self.dead_timer = pygame.time.get_ticks()

            if pygame.time.get_ticks() - self.dead_timer > 2000:
                self.load_level(self.level)
                self.dead = 0
                self.dead_triggered = False

        # Scrolling
        self.scroll[0] += (  # type: ignore
            self.player.rect().centerx - self.display.get_width() / 2 - self.scroll[0]
        ) / 30
        self.scroll[1] += (  # type: ignore
            self.player.rect().centery - self.display.get_height() / 2 - self.scroll[1]
        ) / 30
        render_scroll = (int(self.scroll[0]), int(self.scroll[1]))

        # Spawn and update world entities
        for rect in self.leaf_spawners:
            if random.random() * 49999 < rect.width * rect.height:
                pos = (
                    rect.x + random.random() * rect.width,
                    rect.y + random.random() * rect.height,
                )
                self.particles.append(
                    Particles(
                        self,
                        "leaf",
                        pos,
                        velocity=[-0.1, 0.3],
                        frame=random.randint(0, 20),
                    )
                )

        self.clouds.update()
        self.clouds.render(self.display, offset=render_scroll)
        self.tilemap.render(self.display, offset=render_scroll)

        for enemy in self.enemies.copy():
            kill = enemy.update(self.tilemap, (0, 0))
            enemy.render(self.display, offset=render_scroll)
            if kill:
                self.enemies.remove(enemy)

        if not self.dead:
            self.player.update(self.tilemap, (self.movement[1] - self.movement[0], 0))
            self.player.render(self.display, offset=render_scroll)

        for projectile in self.projectiles.copy():
            projectile[0][0] += projectile[1]
            projectile[2] += 1
            img = self.assets["projectile"]
            self.display.blit(
                img,
                (
                    projectile[0][0] - img.get_width() / 2 - render_scroll[0],
                    projectile[0][1] - img.get_height() / 2 - render_scroll[1],
                ),
            )
            if self.tilemap.solid_check(projectile[0]):
                self.projectiles.remove(projectile)
                for i in range(4):
                    self.sparks.append(
                        Sparks(
                            projectile[0],
                            random.random()
                            - 0.5
                            + (math.pi if projectile[1] > 0 else 0),
                            2 + random.random(),
                        )
                    )
            elif projectile[2] > 360:
                self.projectiles.remove(projectile)
            elif abs(self.player.dashing) < 50:
                if self.player.rect().collidepoint(projectile[0]):
                    self.projectiles.remove(projectile)
                    self.dead += 1
                    self.sfx["hit"].play()
                    self.screenshake = max(16, self.screenshake)
                    for i in range(30):
                        angle = random.random() * math.pi * 2
                        speed = random.random() * 5
                        self.sparks.append(
                            Sparks(
                                self.player.rect().center,
                                angle,
                                2 + random.random(),
                            )
                        )
                        self.particles.append(
                            Particles(
                                self,
                                "strike",
                                self.player.rect().center,
                                velocity=[
                                    math.cos(angle + math.pi) * speed * 0.5,
                                    math.sin(angle + math.pi) * speed * 0.5,
                                ],
                                frame=random.randint(0, 7),
                            )
                        )

        for spark in self.sparks.copy():
            kill = spark.update()
            spark.render(self.display, offset=render_scroll)
            if kill:
                self.sparks.remove(spark)

        # display_mask = pygame.mask.from_surface(self.display)
        # display_sillhouette = display_mask.to_surface(
        #     setcolor=(0, 0, 0, 180), unsetcolor=(0, 0, 0, 0)
        # )
        # for offset in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
        #     self.display_2.blit(display_sillhouette, offset)

        for particle in self.particles.copy():
            kill = particle.update()
            particle.render(self.display, offset=render_scroll)
            if particle.type == "leaf":
                particle.pos[0] += math.sin(particle.animation.frame * 0.035) * 0.3
            if kill:
                self.particles.remove(particle)

        # Input handler
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_LEFT:
                    self.movement[0] = True
                if event.key == pygame.K_RIGHT:
                    self.movement[1] = True
                if event.key == pygame.K_UP or event.key == pygame.K_SPACE:
                    if self.player.jump():
                        self.sfx["jump"].play()
                if event.key == pygame.K_x:
                    self.player.dash()

            if event.type == pygame.KEYUP:
                if event.key == pygame.K_LEFT:
                    self.movement[0] = False
                if event.key == pygame.K_RIGHT:
                    self.movement[1] = False

        # Render frame
        if self.transition:
            t = abs(self.transition) / 30
            width = int(self.display.get_width() * t * 0.5)

            left_rect = pygame.Rect(0, 0, width, self.display.get_height())
            right_rect = pygame.Rect(
                self.display.get_width() - width,
                0,
                width,
                self.display.get_height(),
            )

            pygame.draw.rect(self.display, (0, 0, 0), left_rect)
            pygame.draw.rect(self.display, (0, 0, 0), right_rect)

        # self.display_2.blit(self.display, (0, 0))
        screenshake_offset = (
            random.random() * self.screenshake - self.screenshake / 2,
            random.random() * self.screenshake - self.screenshake / 2,
        )
        # import time

        # t = time.time()
        # self.screen.blit(
        #     pygame.transform.scale(self.display, self.screen.get_size()),
        #     screenshake_offset,
        # )
        # print(f"scale+blit: {(time.time() - t) * 1000:.2f}ms")
        self.screen.blit(self.display, screenshake_offset)
        pygame.display.update()
        self.clock.tick(0)
